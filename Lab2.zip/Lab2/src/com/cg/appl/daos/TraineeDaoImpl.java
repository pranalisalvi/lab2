package com.cg.appl.daos;

import java.util.List; 

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;

@Repository("traineeDao")
public class TraineeDaoImpl implements TraineeDao {

	private EntityManagerFactory factory;
	
	@Resource(name="entityMFactory")
	public void setEntityMFactory(EntityManagerFactory factory) {
		this.factory= factory;
	}

	@Override
	public Trainee getTraineeDetails(int traineeId) throws TraineeException {
		
		EntityManager manager= factory.createEntityManager();
		Trainee trainee= manager.find(Trainee.class, traineeId);
		
		return trainee;
	}

	@Override
	public List<Trainee> getAllTrainee() throws TraineeException {
		String qryStr="select t from trainee t";
		EntityManager manager= factory.createEntityManager();
		Query qry= manager.createQuery(qryStr, Trainee.class);
		return qry.getResultList();
	}

	@Override
	public Trainee insertNewTrainee(Trainee trainee) throws TraineeException {
		EntityManager manager= factory.createEntityManager();
		try {
			EntityTransaction trans= manager.getTransaction();
			trans.begin();
			manager.persist(trainee);
			trans.commit();
		} catch (RollbackException e) {
			throw new TraineeException("Record not commited",e);
		}
		return trainee;
	}

	
	@Override
	public Trainee updateTrainee(Trainee trainee) throws TraineeException {
		EntityManager manager= factory.createEntityManager();
		manager.getTransaction().begin();
		int id= trainee.getTraineeId();
		System.out.println("Update id: "+id);
		Trainee trainee1= this.getTraineeDetails(id);
		
		System.out.println(trainee1);
		trainee1.setTraineeDomain(trainee.getTraineeDomain());
		trainee1.setTraineeLocation(trainee.getTraineeLocation());
		trainee1.setTraineeName(trainee.getTraineeName());
		
		manager.merge(trainee1);
		
		manager.getTransaction().commit();
		return trainee1;
	}

}
